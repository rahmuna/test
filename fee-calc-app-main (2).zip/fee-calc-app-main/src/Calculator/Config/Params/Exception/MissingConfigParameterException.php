<?php

declare(strict_types=1);

namespace FeeCalcApp\Calculator\Config\Params\Exception;

class MissingConfigParameterException extends \RuntimeException
{
}
