<?php

declare(strict_types=1);

namespace FeeCalcApp\Exception;

use RuntimeException;

class BadResponseException extends RuntimeException
{
}
